package be.cercle.asblcercle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsblCercleApplicationTests {

    @Test
    void contextLoads() {
    }

}
