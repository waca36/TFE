package be.cercle.asblcercle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsblCercleApplication {

    public static void main(String[] args) {
        SpringApplication.run(AsblCercleApplication.class, args);
    }

}
