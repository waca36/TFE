package be.cercle.asblcercle.entity;

public enum GarderieReservationStatus {
    CONFIRMED,
    CANCELLED
}
