package be.cercle.asblcercle.entity;

public enum EspaceStatus {
    AVAILABLE,
    UNAVAILABLE
}
