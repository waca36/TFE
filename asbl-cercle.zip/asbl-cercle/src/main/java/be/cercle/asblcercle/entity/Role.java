package be.cercle.asblcercle.entity;

public enum Role {
    MEMBER,
    ORGANIZER,
    ADMIN
}
