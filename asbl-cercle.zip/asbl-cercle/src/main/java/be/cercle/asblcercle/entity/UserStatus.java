package be.cercle.asblcercle.entity;

public enum UserStatus {
    ACTIVE,
    INACTIVE
}
