package be.cercle.asblcercle.entity;

public enum EventStatus {
    DRAFT,
    PUBLISHED,
    CANCELLED
}
