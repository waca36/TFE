package be.cercle.asblcercle.entity;

public enum GarderieSessionStatus {
    OPEN,
    FULL,
    CANCELLED
}
