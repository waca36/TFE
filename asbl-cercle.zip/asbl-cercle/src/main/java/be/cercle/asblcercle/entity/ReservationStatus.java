package be.cercle.asblcercle.entity;

public enum ReservationStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
